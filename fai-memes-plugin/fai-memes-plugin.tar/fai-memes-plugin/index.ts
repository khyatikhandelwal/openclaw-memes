/**
 * fai-memes — OpenClaw plugin
 * Generates and sends AI memes using the Fai Meme API (https://thefaiapp.com/api)
 */

const FAI_API_BASE = "https://thefaiapp.com/api";

// The 7 supported meme image formats
const MEME_FORMATS = [
  "standard",
  "wide",
  "tall",
  "square",
  "classic",
  "minimal",
  "bold",
] as const;

type MemeFormat = (typeof MEME_FORMATS)[number];

interface FaiMemeResponse {
  url?: string;
  image_url?: string;
  video_url?: string;
  media_url?: string;
  format?: string;
  [key: string]: unknown;
}

interface PluginConfig {
  apiKey?: string;
  defaultFormat?: MemeFormat;
}

async function fetchMeme(
  topic: string,
  format: MemeFormat,
  apiKey?: string
): Promise<FaiMemeResponse> {
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    Accept: "application/json",
  };

  if (apiKey) {
    headers["Authorization"] = `Bearer ${apiKey}`;
    headers["X-API-Key"] = apiKey;
  }

  const body: Record<string, string> = {
    topic,
    format,
    type: "image",
  };

  const response = await fetch(`${FAI_API_BASE}/meme`, {
    method: "POST",
    headers,
    body: JSON.stringify(body),
  });

  if (!response.ok) {
    // Try GET fallback with query params
    const params = new URLSearchParams({ topic, format });
    const getResponse = await fetch(`${FAI_API_BASE}/meme?${params}`, {
      headers,
    });
    if (!getResponse.ok) {
      throw new Error(
        `Fai API error: ${response.status} ${response.statusText}`
      );
    }
    return getResponse.json() as Promise<FaiMemeResponse>;
  }

  return response.json() as Promise<FaiMemeResponse>;
}

function extractMediaUrl(data: FaiMemeResponse): string | null {
  return (
    data.url ||
    data.image_url ||
    data.video_url ||
    data.media_url ||
    null
  );
}

export default function register(api: {
  registerTool: (tool: object) => void;
  registerCommand: (cmd: object) => void;
  config?: { plugins?: { entries?: { "fai-memes"?: { config?: PluginConfig } } } };
  logger?: { info: (msg: string) => void; error: (msg: string) => void };
}) {
  const pluginCfg: PluginConfig =
    (api.config?.plugins?.entries?.["fai-memes"]?.config as PluginConfig) ?? {};

  const defaultFormat: MemeFormat = pluginCfg.defaultFormat ?? "standard";
  const apiKey = pluginCfg.apiKey;

  // ─── Agent Tool: generate_meme ────────────────────────────────────────────
  api.registerTool({
    name: "generate_meme",
    description:
      "Generate an AI meme image using the Fai Meme API. " +
      "Returns a URL to the meme image/video that can be shared in chat. " +
      `Available formats: ${MEME_FORMATS.join(", ")}. ` +
      "Use this when the user asks to send a meme, react with a meme, or share a funny image.",
    inputSchema: {
      type: "object",
      required: ["topic"],
      additionalProperties: false,
      properties: {
        topic: {
          type: "string",
          description:
            "What the meme should be about. Be descriptive — e.g. 'Monday morning coffee struggles', 'AI taking over the world but it's fine', 'cat knocking things off a table'.",
        },
        format: {
          type: "string",
          enum: MEME_FORMATS,
          description: `Image format/layout for the meme. Options: ${MEME_FORMATS.join(
            ", "
          )}. Defaults to '${defaultFormat}'.`,
        },
      },
    },
    async run({
      topic,
      format,
    }: {
      topic: string;
      format?: MemeFormat;
    }): Promise<{ text: string }> {
      const chosenFormat: MemeFormat = format ?? defaultFormat;

      api.logger?.info(
        `[fai-memes] Generating meme: topic="${topic}", format="${chosenFormat}"`
      );

      let data: FaiMemeResponse;
      try {
        data = await fetchMeme(topic, chosenFormat, apiKey);
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        api.logger?.error(`[fai-memes] API error: ${msg}`);
        return {
          text: `Sorry, I couldn't generate a meme right now. (${msg})`,
        };
      }

      const mediaUrl = extractMediaUrl(data);

      if (!mediaUrl) {
        api.logger?.error(
          `[fai-memes] No URL in response: ${JSON.stringify(data)}`
        );
        return {
          text: "Meme was generated but no URL was returned. Please try again.",
        };
      }

      api.logger?.info(`[fai-memes] Meme URL: ${mediaUrl}`);

      return {
        text: mediaUrl,
      };
    },
  });

  // ─── Slash Command: /meme ─────────────────────────────────────────────────
  api.registerCommand({
    name: "meme",
    description:
      "Generate and send a meme. Usage: /meme <topic> [--format standard|wide|tall|square|classic|minimal|bold]",
    acceptsArgs: true,
    requireAuth: true,
    async handler(ctx: {
      args?: string;
      channel: string;
    }): Promise<{ text: string }> {
      const raw = (ctx.args ?? "").trim();

      if (!raw) {
        return {
          text:
            "Usage: `/meme <topic> [--format <format>]`\n" +
            `Available formats: ${MEME_FORMATS.join(", ")}\n` +
            "Example: `/meme cat mondays --format wide`",
        };
      }

      // Parse optional --format flag
      const formatMatch = raw.match(/--format\s+(\S+)/i);
      const rawFormat = formatMatch?.[1]?.toLowerCase();
      const chosenFormat: MemeFormat = MEME_FORMATS.includes(
        rawFormat as MemeFormat
      )
        ? (rawFormat as MemeFormat)
        : defaultFormat;

      const topic = raw.replace(/--format\s+\S+/gi, "").trim();

      if (!topic) {
        return { text: "Please provide a topic for the meme." };
      }

      let data: FaiMemeResponse;
      try {
        data = await fetchMeme(topic, chosenFormat, apiKey);
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        return { text: `Couldn't generate meme: ${msg}` };
      }

      const mediaUrl = extractMediaUrl(data);

      if (!mediaUrl) {
        return { text: "Meme generated but no URL returned. Try again!" };
      }

      return { text: mediaUrl };
    },
  });
}
